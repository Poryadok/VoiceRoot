go test -json -v -count=1 -timeout=120s ./internal/principalruntime -run \^\(TestRuntimeListenerCreationPermissionExactSignedBranch\|TestRuntimeListenerNicknamePermissionExactSignedBranch\)\$ 
