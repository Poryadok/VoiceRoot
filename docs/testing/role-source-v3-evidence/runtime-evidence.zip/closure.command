go list -mod=readonly -deps -test -json ./internal/principalruntime ./internal/principalgrpc ./internal/grpcsvc 
