import hashlib
import json
from pathlib import Path, PurePosixPath

out = Path('/evidence')
root = Path('/work')
text = (out / 'closure.jsonl').read_text()
decode = json.JSONDecoder()
objects = []
pos = 0
while pos < len(text):
    while pos < len(text) and text[pos].isspace():
        pos += 1
    if pos == len(text):
        break
    obj, pos = decode.raw_decode(text, pos)
    objects.append(obj)
fields = ('GoFiles', 'CgoFiles', 'CFiles', 'CXXFiles', 'MFiles', 'HFiles',
          'FFiles', 'SFiles', 'SwigFiles', 'SwigCXXFiles', 'SysoFiles',
          'TestGoFiles', 'XTestGoFiles', 'EmbedFiles', 'TestEmbedFiles', 'XTestEmbedFiles')
paths, directories, modules = set(), set(), set()
for obj in objects:
    directory = Path(obj.get('Dir', '/outside'))
    if directory.is_relative_to(root):
        directories.add(directory.relative_to(root).as_posix())
        for field in fields:
            for name in obj.get(field, []):
                path = directory / name
                if path.is_relative_to(root) and path.is_file():
                    paths.add(path.relative_to(root).as_posix())
    for mod in (obj.get('Module') or {}, (obj.get('Module') or {}).get('Replace') or {}):
        directory = Path(mod.get('Dir', '/outside'))
        if directory.is_relative_to(root):
            modules.add(directory.relative_to(root).as_posix())
tree = {}
for row in (out / 'tree.bin').read_bytes().split(b'\0'):
    if row:
        desc, name = row.decode().split('\t', 1)
        mode, kind, oid = desc.split()
        tree[name] = {'mode': mode, 'type': kind, 'oid': oid}
inventories = {d: sorted(p for p in tree if str(PurePosixPath(p).parent) == d) for d in sorted(directories)}
manifests = sorted(p for d in modules for p in (d + '/go.mod', d + '/go.sum') if p in tree)
old = json.loads((root / 'docs/testing/role-checkpermission-source-v2-closure.json').read_text())
old_paths = set(old['paths'])
all_paths = set(paths) | {p for vals in inventories.values() for p in vals} | set(manifests) | {'docs/microservices/role-service.md'}
result = {'source': '70a3ca533e23d7454782428304c180e76fad74e1',
          'tree': '7545653c7fe149d95e685b5e1b886772bad2499e',
          'command': 'go list -mod=readonly -deps -test -json ./internal/principalruntime ./internal/principalgrpc ./internal/grpcsvc',
          'go_list_sha256': hashlib.sha256((out / 'closure.jsonl').read_bytes()).hexdigest(),
          'fields': fields, 'object_count': len(objects), 'compiled_paths': sorted(paths),
          'package_inventories': [{'directory': d, 'paths': v} for d, v in inventories.items()],
          'module_manifests': manifests, 'paths': sorted(all_paths),
          'entries': {p: tree.get(p) for p in sorted(all_paths)},
          'missing_from_tree': sorted(all_paths - tree.keys()),
          'added_vs_v2': sorted(all_paths - old_paths), 'removed_vs_v2': sorted(old_paths - all_paths)}
(out / 'derived-closure.json').write_text(json.dumps(result, indent=2) + '\n')
