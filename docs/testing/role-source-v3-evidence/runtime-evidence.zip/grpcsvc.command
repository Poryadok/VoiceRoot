go test -json -v -count=1 -timeout=120s ./internal/grpcsvc -run \^TestNicknamePermission_DirectUnsignedHandlerDeniesBeforeStore\$ 
