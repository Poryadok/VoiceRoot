#!/bin/bash
set -u
export GOWORK=off GOMAXPROCS=2 GOFLAGS=-p=2
mkdir -p /work
tar -xf /evidence/source.tar -C /work || exit 1
cd /work/src/backend/role || exit 1
{ date -u; uname -a; go version; go env GOOS GOARCH CGO_ENABLED GOWORK GOFLAGS; printf '%s\n' 'source=70a3ca533e23d7454782428304c180e76fad74e1' 'image=golang:1.26.5-bookworm' 'GOMAXPROCS=2' 'no external PostgreSQL, NATS or Docker socket'; } > /evidence/environment.txt
run() { name=$1; shift; printf '%q ' "$@" > "/evidence/$name.command"; printf '\n' >> "/evidence/$name.command"; "$@" > "/evidence/$name.jsonl" 2> "/evidence/$name.stderr"; rc=$?; printf '%s\n' "$rc" > "/evidence/$name.exit"; }
run closure go list -mod=readonly -deps -test -json ./internal/principalruntime ./internal/principalgrpc ./internal/grpcsvc
run listener go test -json -v -count=1 -timeout=120s ./internal/principalruntime -run '^(TestRuntimeListenerCreationPermissionExactSignedBranch|TestRuntimeListenerNicknamePermissionExactSignedBranch)$'
run principalgrpc go test -json -v -count=1 -timeout=120s ./internal/principalgrpc -run '^(TestCreationDecision_OnlyExactSpaceSubjectPermission|TestCreationDecision_StrictBoundaryStopsScopeExpansionBeforeHandler|TestOrdinaryRoleListenerNicknameDeniedOtherPermissionPreserved)$'
run grpcsvc go test -json -v -count=1 -timeout=120s ./internal/grpcsvc -run '^TestNicknamePermission_DirectUnsignedHandlerDeniesBeforeStore$'
date -u > /evidence/finished.txt
