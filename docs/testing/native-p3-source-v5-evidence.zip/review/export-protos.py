import io,pathlib,subprocess,tarfile
root=pathlib.Path(__file__).resolve().parents[2]
out=pathlib.Path(__file__).parent
for name,ref in [('old','ef3dd7f3888bbe2792a9dcec836b2773c4e77962'),('current','b2b566f1103e29058da0e8b786cbd8f0dd028d83')]:
    raw=subprocess.check_output(['git','-C',str(root),'archive',ref,'protos'])
    with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
        tar.extractall(out/name,filter='data')
