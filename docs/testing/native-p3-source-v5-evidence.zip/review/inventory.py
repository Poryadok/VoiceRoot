import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[2]
OLD = 'ef3dd7f3888bbe2792a9dcec836b2773c4e77962'
NEW = 'b2b566f1103e29058da0e8b786cbd8f0dd028d83'
record_path = ROOT / 'docs/testing/native-p3-source-v4.json'
record = json.loads(record_path.read_bytes())
assert record['source'] == OLD

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def entries(ref):
    rows = {}
    for row in git('ls-tree', '-r', '-z', '--full-tree', ref).split(b'\0'):
        if not row:
            continue
        header, path = row.split(b'\t', 1)
        mode, kind, oid = header.decode().split()
        rows[path.decode('utf-8')] = {'mode': mode, 'type': kind, 'oid': oid}
    return rows

before, after = entries(OLD), entries(NEW)
c = record['closure']
dirs = {row['directory'] for row in c['directory_inventories']}
def parent(path):
    return path.rpartition('/')[0]
sets = {
    'projection': set(c['projection_paths']),
    'context': set(c['context_paths']),
    'compiled': set(c['compiled_paths']),
    'directory_inventory': {p for p in before.keys() | after.keys() if parent(p) in dirs},
    'voice_tree': {p for p in before.keys() | after.keys() if p.startswith('src/backend/voice/')},
}
all_paths = set().union(*sets.values())
rows = [dict(path=p, categories=[k for k, s in sets.items() if p in s],
             before=before.get(p), after=after.get(p), changed=before.get(p) != after.get(p))
        for p in sorted(all_paths)]
out = {'schema': 'native-p3-review-inventory-v1', 'status': 'INVENTORY_ONLY_NOT_AUTHORITY',
       'old_source': OLD, 'old_tree': git('rev-parse', OLD + '^{tree}').decode().strip(),
       'new_source': NEW, 'new_tree': git('rev-parse', NEW + '^{tree}').decode().strip(),
       'record_path': 'docs/testing/native-p3-source-v4.json',
       'record_sha256': hashlib.sha256(record_path.read_bytes()).hexdigest(),
       'directory_names': sorted(dirs),
       'category_counts': {k: {'entries': len(s), 'changed': sum(before.get(p) != after.get(p) for p in s)} for k,s in sets.items()},
       'rows': rows}
dest = pathlib.Path(__file__).with_name('inventory.json')
dest.write_text(json.dumps(out, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(dest, hashlib.sha256(dest.read_bytes()).hexdigest(), json.dumps(out['category_counts']))
