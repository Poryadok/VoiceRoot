import collections,hashlib,json,pathlib,subprocess,tarfile
root=pathlib.Path(__file__).resolve().parents[2]; e=root/'tmp/release-history-native-evidence'; out=pathlib.Path(__file__).parent
source='b2b566f1103e29058da0e8b786cbd8f0dd028d83'
def sha(x):return hashlib.sha256(x).hexdigest()
checks=[]
for line in (e/'SHA256SUMS').read_text().splitlines():
    h,p=line.split('  ',1); actual=sha((e/p).read_bytes()); checks.append(dict(path=p,sha256=actual,match=h==actual))
assert all(c['match'] for c in checks)
tree={}
raw=subprocess.check_output(['git','-C',str(root),'ls-tree','-r','-z',source])
for item in raw.split(b'\0'):
    if item:
        meta,path=item.split(b'\t',1); mode,kind,oid=meta.decode().split();tree[path.decode()]=(mode,kind,oid)
archive={}
with tarfile.open(e/'source.tar') as t:
    for m in t:
        if m.isdir():continue
        if m.isfile():data=t.extractfile(m).read();mode='100755' if m.mode&0o111 else '100644'
        elif m.issym():data=m.linkname.encode();mode='120000'
        else:raise ValueError((m.name,m.type))
        archive[m.name]=(mode,'blob',hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
differences=[p for p in sorted(tree.keys()|archive.keys()) if tree.get(p)!=archive.get(p)]
summary=json.loads((e/'test-summary.json').read_bytes()); runs={}
for name in ('root','leave','p3','eject','unknown','ordinary','principal','migration'):
    events=[json.loads(line) for line in (e/(name+'.jsonl')).read_text().splitlines()]
    outcomes=[{'test':x['Test'],'action':x['Action']} for x in events if x.get('Test') and x['Action'] in ('pass','fail','skip')]
    assert outcomes==summary[name]['outcomes']
    actions=collections.Counter(x['action'] for x in outcomes)
    packages=[x for x in events if not x.get('Test') and x['Action'] in ('pass','fail','skip')]
    assert len(packages)==1 and packages[0]['Action']=='pass'
    assert actions['fail']==actions['skip']==0 and (e/(name+'.exit')).read_text().strip()=='0'
    runs[name]=dict(pass_count=actions['pass'],package='pass',sha256=sha((e/(name+'.jsonl')).read_bytes()))
assert not differences
result=dict(source=source,source_tar_sha256=sha((e/'source.tar').read_bytes()),archive_entries=len(archive),tree_entries=len(tree),archive_mismatches=differences,checksum_count=len(checks),checksums=checks,runs=runs)
dest=out/'verified-evidence.json';dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('sha256',sha(dest.read_bytes()),'entries',len(archive),'checksums',len(checks),'testpasses',sum(x['pass_count'] for x in runs.values()))
