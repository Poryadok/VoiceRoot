import hashlib,json,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parents[2]
here=pathlib.Path(__file__).parent
e=root/'tmp/release-history-native-evidence'
new=json.loads((e/'derived-closure.json').read_bytes())
old=json.loads((root/'docs/testing/native-p3-source-v4.json').read_bytes())['closure']['compiled_paths']
added=sorted(set(new['paths'])-set(old))
assert len(added)==20 and not (set(old)-set(new['paths']))
def classify(p):
    if '/authoritysource/' in p:
        return 'GIS-specific authority decoder or its test; compiled shared package, source review finds no Voice caller; context only'
    if '/socialprincipal/' in p:
        return 'test for separate catalog/deletion/notification/account-capture capabilities; shared package test context only'
    if '/catalog_assets' in p:
        return 'generated catalog File/Chat declarations and RPC descriptors; native generated dependency context only'
    if '/reference_inventory' in p:
        return 'generated common/Messaging/Story reference-inventory declarations and RPC descriptors; native generated dependency context only'
    raise ValueError(p)
rows=[]
for p in added:
    raw=subprocess.check_output(['git','-C',str(root),'ls-tree',new['source'],'--',p]).decode().strip()
    meta,_=raw.split('\t',1); mode,kind,oid=meta.split()
    rows.append(dict(path=p,mode=mode,type=kind,oid=oid,classification=classify(p)))
out=dict(source=new['source'],tree=new['tree'],classification='CONTEXT_ONLY_NO_PATH_AUTHORITY',
         derived_sha256=hashlib.sha256((e/'derived-closure.json').read_bytes()).hexdigest(),
         raw_go_list_sha256=hashlib.sha256((e/'closure.jsonl').read_bytes()).hexdigest(),
         directory_inventory_sha256=hashlib.sha256((e/'directory-inventory.json').read_bytes()).hexdigest(),
         rows=rows)
dest=here/'closure-classification.json'; dest.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(hashlib.sha256(dest.read_bytes()).hexdigest())
