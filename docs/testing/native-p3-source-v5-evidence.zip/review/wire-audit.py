import hashlib,json,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parents[2]; here=pathlib.Path(__file__).parent
ref='b2b566f1103e29058da0e8b786cbd8f0dd028d83'
def sha(x): return hashlib.sha256(x).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',str(root),*args])
old={f['name']:f for f in json.loads((here/'old-descriptors.json').read_bytes())['file']}
new={f['name']:f for f in json.loads((here/'current-descriptors.json').read_bytes())['file']}
targets=['voice/chat/v1/chat.proto','voice/file/v1/file.proto','voice/messaging/v1/messaging.proto','voice/user/v1/user.proto']
issues=[]; count={'messages':0,'fields':0,'enums':0,'enum_values':0,'services':0,'methods':0}
def compare_enum(a,b,where):
    count['enums']+=1
    vals={(v['name'],v['number']) for v in b.get('value',[])}
    for v in a.get('value',[]):
        count['enum_values']+=1
        if (v['name'],v['number']) not in vals: issues.append(where+'.'+v['name'])
def compare_msg(a,b,where):
    count['messages']+=1
    fs={x['number']:x for x in b.get('field',[])}
    for f in a.get('field',[]):
        count['fields']+=1; g=fs.get(f['number'])
        keys=('name','number','label','type','typeName','defaultValue','oneofIndex','jsonName','proto3Optional','extendee')
        if g is None or any(f.get(k)!=g.get(k) for k in keys): issues.append(where+'.'+f['name'])
    for kind, fn in [('nestedType',compare_msg),('enumType',compare_enum)]:
        lookup={x['name']:x for x in b.get(kind,[])}
        for x in a.get(kind,[]):
            if x['name'] not in lookup: issues.append(where+'.'+x['name'])
            else: fn(x,lookup[x['name']],where+'.'+x['name'])
for path in targets:
    a,b=old[path],new[path]
    for kind,fn in [('messageType',compare_msg),('enumType',compare_enum)]:
        lookup={x['name']:x for x in b.get(kind,[])}
        for x in a.get(kind,[]):
            if x['name'] not in lookup: issues.append(path+':'+x['name'])
            else: fn(x,lookup[x['name']],path+':'+x['name'])
    services={x['name']:x for x in b.get('service',[])}
    for svc in a.get('service',[]):
        count['services']+=1; s=services.get(svc['name'])
        if not s: issues.append(path+':'+svc['name']); continue
        methods={x['name']:x for x in s.get('method',[])}
        for m in svc.get('method',[]):
            count['methods']+=1; n=methods.get(m['name'])
            if n is None or any(m.get(k)!=n.get(k) for k in ('inputType','outputType','clientStreaming','serverStreaming')): issues.append(path+':'+svc['name']+'.'+m['name'])
generated=here/'generated/gen/go'; closure=json.loads((root/'tmp/release-history-native-evidence/derived-closure.json').read_bytes())['paths']
rows=[]
for p in closure:
    if '/pb/voice/' not in p or not p.endswith('.pb.go'): continue
    suffix='voice/'+p.split('/pb/voice/',1)[1]
    source=generated/suffix
    if not source.is_file(): continue
    canonical=source.read_bytes(); committed=git('show',ref+':'+p)
    rows.append(dict(path=p,generated_sha256=sha(canonical),git_sha256=sha(committed),equal=canonical==committed))
extras=['voice/chat/v1/chat.proto','voice/file/v1/file.proto','voice/messaging/v1/messaging.proto','voice/user/v1/user.proto','voice/chat/v1/catalog_assets.proto','voice/file/v1/catalog_assets.proto','voice/common/v1/reference_inventory.proto','voice/messaging/v1/reference_inventory.proto','voice/story/v1/reference_inventory.proto']
protos=[]
for p in extras:
    path='protos/'+p; raw=git('ls-tree',ref,'--',path).decode().strip(); meta,_=raw.split('\t',1);mode,kind,oid=meta.split()
    protos.append(dict(path=path,mode=mode,type=kind,oid=oid,sha256=sha(git('show',ref+':'+path))))
out=dict(old='ef3dd7f3888bbe2792a9dcec836b2773c4e77962',current=ref,descriptor_scope=targets,
         descriptor_counts=count,descriptor_issues=issues,
         old_descriptor_sha256=sha((here/'old-descriptors.json').read_bytes()),
         current_descriptor_sha256=sha((here/'current-descriptors.json').read_bytes()),
         generation='buf 1.50.0; protoc-gen-go 1.36.5; protoc-gen-go-grpc 1.5.1; buf.gen.local-go.yaml',
         generated_rows=rows,protos=protos)
dest=here/'wire-audit.json';dest.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('SHA',sha(dest.read_bytes()),'counts',count,'descriptor_issues',len(issues),'generated',len(rows),'mismatch',sum(not x['equal'] for x in rows))
for x in issues: print('ISSUE',x)
for x in rows:
    if not x['equal']:print('MISMATCH',x['path'])
