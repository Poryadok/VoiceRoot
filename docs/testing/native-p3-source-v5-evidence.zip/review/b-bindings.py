import hashlib, json, pathlib, subprocess
root=pathlib.Path(__file__).resolve().parents[2]
old='ef3dd7f3888bbe2792a9dcec836b2773c4e77962'
new='b2b566f1103e29058da0e8b786cbd8f0dd028d83'
binding=root/'docs/testing/native-p3-source-v2-evidence/historical-proof-bindings.json'
b=json.loads(binding.read_bytes())
def sha(v): return hashlib.sha256(v).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',str(root),*args])
def entry(ref,path):
    raw=git('ls-tree',ref,'--',path).decode().strip()
    if not raw: return None
    meta,name=raw.split('\t',1); mode,kind,oid=meta.split()
    return dict(mode=mode,type=kind,oid=oid,sha256=sha(git('show',ref+':'+path)))
files=[]
for x in b['proof_files']+[b['original_b3_receipt_unpinned_supplement']]:
    p=pathlib.Path(x['path'])
    actual=sha(p.read_bytes()) if p.exists() else None
    files.append(dict(path=x['path'],sha256=actual,expected=x['sha256'],matches=actual==x['sha256']))
assert all(x['matches'] for x in files)
paths={x['path'] for k in ('B1','B2','B3','B4') for x in b['clause_source_entries'][k]}
paths.update(['src/backend/voice/internal/spacemedia/postgres_admission_integration_test.go',
              'src/backend/voice/internal/spacemedia/p3_down_retention_integration_test.go',
              'src/backend/voice/internal/spacegatetest/postgres.go',
              'src/backend/pkg/integrationtest/postgres.go',
              'src/backend/pkg/integrationtest/migrations.go'])
paths.update(p for p in git('ls-tree','-r','--name-only',old,'--','src/backend/migrations/voice_db').decode().splitlines())
rows=[dict(path=p,before=entry(old,p),after=entry(new,p)) for p in sorted(paths)]
out=dict(old_source=old,new_source=new,historical_binding_sha256=sha(binding.read_bytes()),
         historical_proof_files=files,source_entries=rows)
dest=pathlib.Path(__file__).with_name('b-bindings.json')
dest.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('sha256',sha(dest.read_bytes()),'rows',len(rows),'changed',[(x['path']) for x in rows if x['before']!=x['after']])
