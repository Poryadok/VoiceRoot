# Native/P3 current-source independent review — evidence pending

This is an independent bounded source review, not a qualification, test receipt,
runtime PASS, path grant, or approval of a successor record. No tests were run.
Historical records must remain immutable. Current event identity and production
bootstrap are separate from the source comparison below.

The admitted `load_context_record` v4 record is commit
`60c0a1fd66d090956113c395d8447edc47b95772`, raw SHA-256
`3bec6a20906f6a96ba2e77d5f4b243e415b5f0ed7f724d88e6c4643446099e53`;
its source is `ef3dd7f3888bbe2792a9dcec836b2773c4e77962` (tree
`8c2e625484e18d015e5ff3f353367cfda87bf975`). Reviewed comparison target is
`b2b566f1103e29058da0e8b786cbd8f0dd028d83` (tree
`17fd016468515ed564ab995c5e81267474bf9473`). This comparison does not establish
that this target is the eventual H or prove event ancestry/parentage. Recompute
against final H. The old v4 event base `2c8bdf9e2f420b724575096beb4fcf5cb4ea00be`
is not the current event base; historical bootstrap is not current authority.

`inventory.json` SHA-256
`9084a276a78d18478f78b018ba2a86606b79b1aa0fb929dff97096b719850b62`
is the companion reproducible inventory. It lists every old projection/context/
compiled path, every immediate entry of the 89 compiled dependency directories
on either tree, and every Voice tree entry on either tree; rows include old and
new Git mode/type/OID or null and category membership. This is an old-closure
inventory, not a newly derived Linux go-list closure. It has 99 projection
(3 changed), 472 context (24 changed), 481 compiled (20 changed), 540 union
directory entries (40 changed), and 356 union Voice entries (18 changed).
The changed projection is exactly `docs/DATA_STORES.md`,
`docs/microservices/space-service.md`, and `src/backend/voice/jwks_recovery_test.go`.
Directory additions and the whole Voice pathset cannot be ignored merely because
they were absent from the old 481-path compiled manifest.

## Semantics and limits

* The Voice test adds a real process-child restart over durable PostgreSQL and
  NATS, cold Space JWKS, blocked readiness, production factory and fail-closed
  TLS/Space/Auth/Role cases; dependencies are fixtures, not end-to-end provider
  acceptance. It checks persisted active admission and zero leased/delivered
  roster rows. It must actually run on H, including subtests, without skip.
* `socialprincipal` changes issuer selection from one expected issuer to an
  allowed list. For existing `space-voice-communication`, `capabilityIssuers`
  still returns the single `expectedIssuer` (`voice`); `StrictUnaryInterceptor`
  checks allowed issuer and `service:` + that issuer, retaining the old equality
  for that capability. Catalog is deliberately multi-issuer; new method cases
  and Messaging's additional deletion method are distinct capabilities. This is
  a source-level inference only: changed common authentication requires signed
  runtime, negative-method, subject, request-binding, replay and cold-key tests.
* `integrationtest.ApplySQLFile` now recursively applies Messaging 038 after
  Messaging 015, itself reachable through Messaging 012. The new condition is
  on a Messaging suffix; Voice 012/013/014 do not match it. This is not evidence
  that any particular historical B driver avoids Messaging 015. Inspect the
  exact original drivers, helper imports and fixture path lists before reusing;
  if any executes this chain, bind 038 and its dependencies and rerun affected
  proof. No unchanged-Voice-migration assertion substitutes for that audit.
* Voice migrations and the `internal/spacemedia`, `internal/spacelifecycle`,
  and `internal/rosteroutbox` trees have no v4-to-target tracked diffs. This
  preserves their old Git entries but does not prove the changed dependency
  closure or complete current execution. DATA_STORES changes are cross-service
  retention/catalog contracts; Space doc adds catalog and User/Space cold-start
  detail. Makefile adds release/frontend test targets; NATS config adds notification
  subject/stream permissions. File proto and generated descriptors change and
  new generated packages appear: independently verify native reachable wire
  compatibility and complete current go-list closure before reuse.

## Literal clause applicability and required evidence

Historical facts are reusable only if original literal drivers, SQL, data,
tools, fixtures and all relevant transitive dependencies are shown equal or
the precise difference is independently reviewed. For all clauses the current
outcome remains OPEN until H-bound evidence is examined.

* A1: historical root RED and old factory GREEN remain historical. Obtain fresh
  actual root/factory and protected Role/Space checker results with current signed
  principal code. A2: prove ordinary-only and Space/NATS branches leave native
  roster facts unleased/undelivered, including no-NATS restrictive gate.
* A3: retain historical exact transaction, replay, rollback and pending-state
  proofs within their original bounds. Run the actual child restart with explicit
  disposable database DSN and NATS; verify all success and failure subtests,
  process identities, zero skips, persisted row and no roster lease/delivery.
  The new test is supplementary and does not by itself establish every historical
  transaction claim. Run delayed stale Leave as well.
* A4: retain literal EJECT_ONLY/no retirement/full FROZEN/LIVE and UNKNOWN facts
  only after reviewing changed dependencies. Run current restrictive composition,
  provider retirement and communication-denial tests; validate exact retained
  targets and recovery evidence, with no claim of provider activation.
* B1: original literal 014 empty DOWN/UP and collateral snapshot; B2: retained
  lifecycle classes refuse destructive DOWN with exact rows; B3: literal writer
  win, DOWN-first exclusion, partial-DDL and timeout rollback are synchronized
  observations. Original 014 driver excluded 012, so preserve that scope and
  separately obtain 012 READ COMMITTED lock/retention evidence. Exact old SQL and
  helper/driver identity and changed integrationtest chain must be checked.
* B4: preserve exact 013 outbox/counter refusal, snapshot guard and no MM020
  import, after exact input/driver comparison. Current targeted test commands
  below supplement but do not replace literal external B1/B2/B3 drivers.

## Concrete H-bound evidence requests

Run in isolated Linux at exact final H with disposable PostgreSQL and NATS, not
production resources. Capture commit/tree, Go version, environment names without
secrets, commands, complete `go test -json` streams and counts including skips,
exit codes and fixture/driver SHA-256. `VOICE_COMPOSITION_TEST_DATABASE_URL` must
point to a disposable administrative PostgreSQL DSN and
`VOICE_COMPOSITION_TEST_NATS_URL` to disposable NATS for real-child cases.
Do not use `-short`; use `-count=1`. These commands are proposed, not executed:

From `src/backend/voice`:

```sh
rtk proxy go test -json -count=1 -race -run '^(TestProductionSpaceMediaFactoryPreservesLiveAdmissionThroughBothStartupPasses|TestProductionSpaceMediaFactoryKeepsNativeRosterDormant|TestProductionSpaceMediaFactoryP3WithoutNATSUsesRestrictiveGate|TestProductionRootKeepsUnqualifiedRosterRelayDormant|TestNonemptyAdmissionRecoveryNeedsPublishedVoiceJWKS|TestVoiceProcessRestartRecoversNonemptyAdmission)$' .
rtk proxy go test -json -count=1 -race -run '^TestOrdinaryDelayedLeaveCannotRemoveReplacementGeneration$' ./internal/grpcsvc
rtk proxy go test -json -count=1 -race -run '^(TestP3CurrentNativeCompositionWithoutLegacyOrRedis|TestP3DownRefusesRetainedGrantTargetsAndReceipt|TestP3DownEmptyRoundtrip|TestP3DownSerializesWithUncommittedNativeWriter|TestNativeDownRejectsInheritedRepeatableReadSnapshot|TestRosterDownRetainsIndependentHistory|TestP3DownRetainsIndependentLifecycleEvidence)$' ./internal/spacemedia
rtk proxy go test -json -count=1 -race -run '^TestEjectOnlyCannotCompleteFreezeOrAuthorizeLive$' ./internal/spacelifecycle
rtk proxy go test -json -count=1 -race -run '^TestSpaceTimeoutAndUnknownCapabilityDenyBeforeRoleRosterAndToken$' ./internal/grpcsvc
rtk proxy go test -json -count=1 -race -run '^(TestOrdinaryDownRetainsConcurrentFirstWriter|TestOrdinaryDownRejectsInheritedSnapshot|TestOrdinaryEmptyDownUp)$' ./internal/ordinarycall
```

From `src/backend/pkg`:

```sh
rtk proxy go test -json -count=1 -race -run '^(TestSpaceCommunicationCapabilitiesAreExact|TestSpaceCommunicationRuntimeProtectsBothExactCapabilities|TestCredentialTemporalAndMethodScope|TestCatalogActorConfigRequiresBothIssuersAndCompleteIdentity|TestCatalogActorSignedPrincipalMatrix)$' ./socialprincipal
rtk proxy go test -json -count=1 -race -run '^TestMigrationSuffixMatches_' ./integrationtest
```

The commands above do not purport to reproduce the external B1/B2/B3 014 matrix
or prove their exact fixture coverage. Locate the original pinned B1 supplement,
H3 matrix packet and H5 receipt through the v1 evidence names and hash-check the
specific driver/log/SQL inputs; execute the original recorded invocations if the
fixture audit shows changed dependencies. Retain the already bound 012
READ COMMITTED supplement only after verifying its exact source/harness applies
to H, otherwise rerun its original driver and lock/retention assertions.
For generated changes capture current Linux `go list -deps -test -json ./...`,
complete package-directory inventories, toolchain and exact generated/proto
descriptor compatibility plus affected module build/test evidence; review added
paths for native reachability and classify each, never treat context as authority.

An immutable successor requires reviewed H, subsequently committed immutable R
pinning complete source, closure, individual deltas and evidence, and a later K
that pins actual R bytes and checks current event/base, ordered parents, result
tree and conserved historical ledger. SHA substitution in v4, old event reuse,
synthetic trace completion or a record's own PASS string cannot establish this.
