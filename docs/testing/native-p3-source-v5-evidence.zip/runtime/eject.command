go test -json -count=1 -race -run \^TestEjectOnlyCannotCompleteFreezeOrAuthorizeLive\$ ./internal/spacelifecycle 
