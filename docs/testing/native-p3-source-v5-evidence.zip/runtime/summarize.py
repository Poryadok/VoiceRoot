import json
from pathlib import Path

root = Path('/evidence')
summaries = {}
for name in ('root', 'leave', 'p3', 'eject', 'unknown', 'ordinary', 'principal', 'migration'):
    path = root / (name + '.jsonl')
    if not path.exists():
        continue
    events = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    outcomes = [{'test': e.get('Test'), 'action': e['Action']} for e in events
                if e.get('Test') and e.get('Action') in ('pass', 'fail', 'skip')]
    summaries[name] = {'exit': (root / (name + '.exit')).read_text().strip(),
                       'outcomes': outcomes}
(root / 'test-summary.json').write_text(json.dumps(summaries, indent=2) + '\n')
