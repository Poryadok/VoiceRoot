import hashlib
import json
from pathlib import Path

root = Path('tmp/release-history-native-evidence')
summaries = json.loads((root / 'test-summary.json').read_text())
results = {}
for name, data in summaries.items():
    counts = {status: sum(v['action'] == status for v in data['outcomes'])
              for status in ('pass', 'fail', 'skip')}
    results[name] = {'exit': data['exit'], 'counts': counts}
receipt = {'source_commit': 'b2b566f1103e29058da0e8b786cbd8f0dd028d83',
           'source_tree': '17fd016468515ed564ab995c5e81267474bf9473',
           'source_method': 'git archive --format=tar of source commit',
           'runner_image_id': 'sha256:9d092f39a10348f82e2c858d9205463b7dc1c37a651bee91df26b9faec502bae',
           'postgres_image_id': 'sha256:75f5a96988cdf694a215073c3e9c001b706b371e2f94df3967f2efdec2787f6b',
           'nats_image_id': 'sha256:138f6ccc9fd034c76ac3cee7faed6c5fdb874fd333f477b91f52b4052f6669ce',
           'cpu_limits': {'runner': 1.25, 'postgres': 0.5, 'nats': 0.25},
           'closure_exit': (root / 'closure.exit').read_text().strip(),
           'results': results,
           'limitations': ['Does not reproduce literal historical B1/B2/B3 external drivers.',
                           'Fixtures are not full Space/Voice/provider acceptance.',
                           'Closure and directory reachability need independent review.',
                           'No claim of record authority, deployment or source qualification.']}
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
hashes = []
for f in sorted(root.iterdir()):
    if f.is_file() and f.name != 'SHA256SUMS':
        h = hashlib.sha256()
        with f.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(block)
        hashes.append(f'{h.hexdigest()}  {f.name}')
(root / 'SHA256SUMS').write_text('\n'.join(hashes) + '\n')
