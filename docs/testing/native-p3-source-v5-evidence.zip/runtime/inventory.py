import json
from pathlib import Path

root = Path('tmp/release-history-native-evidence')
closure = json.loads((root / 'derived-closure.json').read_text())
old = json.loads(Path('docs/testing/native-p3-source-v2-closure.json').read_text())
paths = set(closure['paths'])
directories = {str(Path(p).parent).replace('\\', '/') for p in paths}
entries = {}
for row in (root / 'tree.bin').read_bytes().split(b'\0'):
    if not row:
        continue
    info, name = row.decode().split('\t', 1)
    mode, kind, oid = info.split()
    if str(Path(name).parent).replace('\\', '/') in directories:
        entries[name] = {'mode': mode, 'type': kind, 'oid': oid, 'compiled': name in paths}
old_paths = set(old['paths'])
out = {'source': closure['source'], 'tree': closure['tree'],
       'compiled_count': len(paths), 'directory_count': len(directories),
       'tracked_entries': entries, 'compiled_missing_from_tree': sorted(paths - entries.keys()),
       'added_vs_v2': sorted(paths - old_paths), 'removed_vs_v2': sorted(old_paths - paths)}
(root / 'directory-inventory.json').write_text(json.dumps(out, indent=2) + '\n')
