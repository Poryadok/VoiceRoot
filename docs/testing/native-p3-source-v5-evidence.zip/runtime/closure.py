import json
from pathlib import Path

data = Path('/evidence/closure.jsonl').read_text()
decoder = json.JSONDecoder()
pos = 0
objects = []
while pos < len(data):
    while pos < len(data) and data[pos].isspace():
        pos += 1
    if pos == len(data):
        break
    obj, pos = decoder.raw_decode(data, pos)
    objects.append(obj)
root = Path('/work')
paths = set()
dirs = set()
fields = ('GoFiles', 'CgoFiles', 'CFiles', 'CXXFiles', 'MFiles', 'HFiles',
          'FFiles', 'SFiles', 'SwigFiles', 'SwigCXXFiles', 'SysoFiles',
          'TestGoFiles', 'XTestGoFiles', 'EmbedFiles', 'TestEmbedFiles', 'XTestEmbedFiles')
for obj in objects:
    directory = Path(obj.get('Dir', '/nonexistent'))
    if not directory.is_relative_to(root):
        continue
    dirs.add(str(directory.relative_to(root)))
    for field in fields:
        for name in obj.get(field, []):
            path = directory / name
            if path.is_relative_to(root) and path.is_file():
                paths.add(str(path.relative_to(root)))
    module = obj.get('Module') or {}
    module_dir = Path(module.get('Dir', '/nonexistent'))
    if module_dir.is_relative_to(root) and (module_dir / 'go.mod').is_file():
        paths.add(str((module_dir / 'go.mod').relative_to(root)))
out = {'source': 'b2b566f1103e29058da0e8b786cbd8f0dd028d83',
       'tree': '17fd016468515ed564ab995c5e81267474bf9473',
       'command': 'go list -mod=readonly -deps -test -json ./...',
       'image': 'golang:1.26.5-bookworm', 'fields': fields,
       'object_count': len(objects), 'paths': sorted(paths), 'package_directories': sorted(dirs)}
Path('/evidence/derived-closure.json').write_text(json.dumps(out, indent=2) + '\n')
