go test -json -count=1 -race -run \^\(TestOrdinaryDownRetainsConcurrentFirstWriter\|TestOrdinaryDownRejectsInheritedSnapshot\|TestOrdinaryEmptyDownUp\)\$ ./internal/ordinarycall 
