#!/bin/bash
set -u
export GOMAXPROCS=2 GOFLAGS=-p=2
export VOICE_COMPOSITION_TEST_DATABASE_URL='postgres://evidence:evidence@native-evidence-b2b-pg:5432/postgres?sslmode=disable'
export VOICE_COMPOSITION_TEST_NATS_URL='nats://native-evidence-b2b-nats:4222'
mkdir -p /work
tar -xf /evidence/source.tar -C /work || exit 1
cd /work/src/backend/voice || exit 1
{ date -u; uname -a; go version; go env GOOS GOARCH CGO_ENABLED GOMAXPROCS; printf '%s\n' 'source=b2b566f1103e29058da0e8b786cbd8f0dd028d83' 'tree=17fd016468515ed564ab995c5e81267474bf9473' 'image=golang:1.26.5-bookworm' 'VOICE_COMPOSITION_TEST_DATABASE_URL=disposable private postgres' 'VOICE_COMPOSITION_TEST_NATS_URL=disposable private nats' 'GOFLAGS=-p=2' 'GOMAXPROCS=2'; } > /evidence/environment.txt
run() { name=$1; shift; printf '%q ' "$@" > "/evidence/$name.command"; printf '\n' >> "/evidence/$name.command"; "$@" > "/evidence/$name.jsonl" 2> "/evidence/$name.stderr"; rc=$?; printf '%s\n' "$rc" > "/evidence/$name.exit"; }
run closure go list -mod=readonly -deps -test -json ./...
run root go test -json -count=1 -race -run '^(TestProductionSpaceMediaFactoryPreservesLiveAdmissionThroughBothStartupPasses|TestProductionSpaceMediaFactoryKeepsNativeRosterDormant|TestProductionSpaceMediaFactoryP3WithoutNATSUsesRestrictiveGate|TestProductionRootKeepsUnqualifiedRosterRelayDormant|TestNonemptyAdmissionRecoveryNeedsPublishedVoiceJWKS|TestVoiceProcessRestartRecoversNonemptyAdmission)$' .
run leave go test -json -count=1 -race -run '^TestOrdinaryDelayedLeaveCannotRemoveReplacementGeneration$' ./internal/grpcsvc
run p3 go test -json -count=1 -race -run '^(TestP3CurrentNativeCompositionWithoutLegacyOrRedis|TestP3DownRefusesRetainedGrantTargetsAndReceipt|TestP3DownEmptyRoundtrip|TestP3DownSerializesWithUncommittedNativeWriter|TestNativeDownRejectsInheritedRepeatableReadSnapshot|TestRosterDownRetainsIndependentHistory|TestP3DownRetainsIndependentLifecycleEvidence)$' ./internal/spacemedia
run eject go test -json -count=1 -race -run '^TestEjectOnlyCannotCompleteFreezeOrAuthorizeLive$' ./internal/spacelifecycle
run unknown go test -json -count=1 -race -run '^TestSpaceTimeoutAndUnknownCapabilityDenyBeforeRoleRosterAndToken$' ./internal/grpcsvc
run ordinary go test -json -count=1 -race -run '^(TestOrdinaryDownRetainsConcurrentFirstWriter|TestOrdinaryDownRejectsInheritedSnapshot|TestOrdinaryEmptyDownUp)$' ./internal/ordinarycall
cd /work/src/backend/pkg || exit 1
run principal go test -json -count=1 -race -run '^(TestSpaceCommunicationCapabilitiesAreExact|TestSpaceCommunicationRuntimeProtectsBothExactCapabilities|TestCredentialTemporalAndMethodScope|TestCatalogActorConfigRequiresBothIssuersAndCompleteIdentity|TestCatalogActorSignedPrincipalMatrix)$' ./socialprincipal
run migration go test -json -count=1 -race -run '^TestMigrationSuffixMatches_' ./integrationtest
date -u > /evidence/finished.txt
