go test -json -count=1 -race -run \^TestMigrationSuffixMatches_ ./integrationtest 
