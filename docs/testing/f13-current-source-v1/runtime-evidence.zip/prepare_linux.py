"""Prepare immutable tracked source and verified download-cache bytes for Linux."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
decoder = json.JSONDecoder()
modules, local = set(), set()
for service in ('role', 'voice'):
    text = (out / (service+'.stdout')).read_text(encoding='utf-8')
    pos = 0
    while pos < len(text):
        while pos < len(text) and text[pos].isspace(): pos += 1
        if pos == len(text): break
        obj, pos = decoder.raw_decode(text, pos)
        module = obj.get('Module') or {}
        module = module.get('Replace') or module
        if module.get('Version'):
            modules.add((module['Path'], module['Version']))
        directory = module.get('Dir')
        if directory:
            path = Path(directory)
            if path.is_relative_to(root): local.add(path.relative_to(root).as_posix())
source = subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
with (out / 'linux-source.tar').open('wb') as stream:
    subprocess.run(['git','-C',str(root),'archive','--format=tar',source,*sorted(local)], stdout=stream, check=True)

cache = Path('C:/Users/Sergey/go/pkg/mod')
def escaped(value):
    return ''.join('!'+c.lower() if c.isupper() else c for c in value)
missing = []
with tarfile.open(out / 'linux-module-downloads.tar','w') as archive:
    for name, version in sorted(modules):
        folder = Path('cache/download') / escaped(name) / '@v'
        for extension in ('mod','info','zip','ziphash'):
            member = folder / (escaped(version)+'.'+extension)
            path = cache / member
            if path.is_file(): archive.add(path, arcname=member.as_posix(), recursive=False)
            else: missing.append(member.as_posix())
receipt = {'source': source, 'module_count': len(modules), 'local_modules': sorted(local),
           'missing_cache_files': missing, 'authority': False}
for name in ('linux-source.tar','linux-module-downloads.tar'):
    raw = (out / name).read_bytes()
    receipt[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
(out / 'linux-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
