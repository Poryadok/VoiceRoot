"""Native Linux evidence from exact Git source on owned Linux Docker volumes."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
mode = sys.argv[1]
service = mode.split('-')[0]
packages = ['./internal/principalruntime','./internal/principalgrpc','./internal/grpcsvc'] if service == 'role' else ['./...']
if '-room-' in mode:
    packages = ['./internal/roomlifecycle']
image = 'golang@sha256:23ce71337b726608afb1bc00986e630a05034a87a87ea1fc2cd1ae5cf33387eb'
command = ['docker','run','--rm','--name','a2-history-wt76-native-'+mode,
           '--cpus','2','--memory','4g','-e','GOMAXPROCS=2',
           '-v','a2-history-6a0d2ad4-source:/work:ro',
           '-v','a2-history-6a0d2ad4-modules:/go/pkg/mod',
           '-e','GOPROXY=off','-w','/work/src/backend/'+service,image]
if mode.endswith('discovery'):
    command += ['go','list','-mod=readonly','-deps','-test','-json',*packages]
else:
    command += ['go','test','-mod=readonly','-p=2','-race','-json','-count=1','-short',*packages]
preparation = json.loads((out/'linux-preparation.json').read_text(encoding='utf-8'))
with (out/(mode+'.stdout')).open('wb') as stdout, (out/(mode+'.stderr')).open('wb') as stderr:
    result = subprocess.run(command,stdout=stdout,stderr=stderr)
receipt = {'source':preparation['source'],'command':command,'exit_code':result.returncode,
           'source_archive':preparation['linux-source.tar'],'image':image,
           'runtime_pass':False,'environment_acceptance':False}
supplemental=out/'linux-migrations-preparation.json'
if supplemental.exists():
    receipt['supplemental_source_archive']=json.loads(supplemental.read_text(encoding='utf-8'))
for stream in ('stdout','stderr'):
    raw=(out/(mode+'.'+stream)).read_bytes()
    receipt[stream]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
if mode.endswith('tests'):
    events=[json.loads(line) for line in (out/(mode+'.stdout')).read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    receipt['test_events']={action:sum(e.get('Action')==action and 'Test' in e for e in events) for action in ('pass','fail','skip')}
(out/(mode+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
sys.exit(result.returncode)
